@extends('layouts.app')
@section('title', 'Edit Peminjaman')

@section('content')

<div class="page-header">
    <h1 class="page-title">Edit Peminjaman</h1>
    <a href="{{ route('peminjaman.index') }}" class="btn btn-neutral">&#8592; Kembali</a>
</div>

<div class="form-card">
    <form method="POST" action="{{ route('peminjaman.update', $peminjaman) }}" novalidate>
        @csrf
        @method('PUT')

        {{-- Kode Peminjaman (readonly) --}}
        <div class="form-group">
            <label class="form-label" for="kode_peminjaman">Kode Peminjaman</label>
            <input type="text"
                   id="kode_peminjaman"
                   class="form-control"
                   value="{{ $peminjaman->kode_peminjaman }}"
                   readonly
                   style="opacity:0.5; cursor:not-allowed;">
        </div>

        <div class="form-group">
            <label class="form-label" for="pengguna_id">Peminjam</label>
            <select id="pengguna_id"
                    name="pengguna_id"
                    class="form-control {{ $errors->has('pengguna_id') ? 'is-invalid' : '' }}">
                @foreach($penggunas as $pengguna)
                    <option value="{{ $pengguna->id }}"
                            {{ old('pengguna_id', $peminjaman->pengguna_id) == $pengguna->id ? 'selected' : '' }}>
                        {{ $pengguna->nama_peminjam }}
                        @if($pengguna->kelas)
                            ({{ $pengguna->kelas }})
                        @endif
                    </option>
                @endforeach
            </select>
            @error('pengguna_id')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        {{-- Barang --}}
        <div class="form-group">
            <label class="form-label" for="barang_id">Barang</label>
            <select id="barang_id"
                    name="barang_id"
                    class="form-control {{ $errors->has('barang_id') ? 'is-invalid' : '' }}">
                @foreach($barangs as $barang)
                    <option value="{{ $barang->id }}"
                            {{ old('barang_id', $peminjaman->barang_id) == $barang->id ? 'selected' : '' }}>
                        {{ $barang->nama_barang }}
                    </option>
                @endforeach
            </select>
            @error('barang_id')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        {{-- Jumlah --}}
        <div class="form-group">
            <label class="form-label" for="jumlah">Jumlah</label>
            <input type="number"
                   id="jumlah"
                   name="jumlah"
                   class="form-control {{ $errors->has('jumlah') ? 'is-invalid' : '' }}"
                   value="{{ old('jumlah', $peminjaman->jumlah) }}"
                   min="1">
            @error('jumlah')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        {{-- Tanggal Pinjam --}}
        <div class="form-group">
            <label class="form-label" for="tanggal_pinjam">Tanggal Pinjam</label>
            <input type="date"
                   id="tanggal_pinjam"
                   name="tanggal_pinjam"
                   class="form-control {{ $errors->has('tanggal_pinjam') ? 'is-invalid' : '' }}"
                   value="{{ old('tanggal_pinjam', $peminjaman->tanggal_pinjam?->format('Y-m-d')) }}">
            @error('tanggal_pinjam')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        {{-- Rencana Tanggal Kembali --}}
        <div class="form-group">
            <label class="form-label" for="tanggal_rencana_kembali">Rencana Tanggal Kembali</label>
            <input type="date"
                   id="tanggal_rencana_kembali"
                   name="tanggal_rencana_kembali"
                   class="form-control {{ $errors->has('tanggal_rencana_kembali') ? 'is-invalid' : '' }}"
                   value="{{ old('tanggal_rencana_kembali', $peminjaman->tanggal_rencana_kembali?->format('Y-m-d')) }}">
            @error('tanggal_rencana_kembali')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        {{-- Tanggal Kembali Aktual --}}
        <div class="form-group">
            <label class="form-label" for="tanggal_kembali">
                Tanggal Kembali Aktual
                <span style="color:var(--text-muted); font-weight:400; text-transform:none;">
                    (isi jika sudah dikembalikan)
                </span>
            </label>
            <input type="date"
                   id="tanggal_kembali"
                   name="tanggal_kembali"
                   class="form-control {{ $errors->has('tanggal_kembali') ? 'is-invalid' : '' }}"
                   value="{{ old('tanggal_kembali', $peminjaman->tanggal_kembali?->format('Y-m-d')) }}">
            @error('tanggal_kembali')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        {{-- Status --}}
        <div class="form-group">
            <label class="form-label" for="status">Status</label>
            <select id="status"
                    name="status"
                    class="form-control {{ $errors->has('status') ? 'is-invalid' : '' }}">
                @php $currentStatus = $peminjaman->status instanceof \App\Enums\LoanStatus ? $peminjaman->status->value : $peminjaman->status; @endphp
                <option value="Dipinjam"     {{ old('status', $currentStatus) === 'Dipinjam'     ? 'selected' : '' }}>Dipinjam</option>
                <option value="Dikembalikan" {{ old('status', $currentStatus) === 'Dikembalikan' ? 'selected' : '' }}>Dikembalikan</option>
                @if($currentStatus === 'Terlambat')
                    <option value="Terlambat" selected disabled>Terlambat (legacy)</option>
                @endif
            </select>
            @error('status')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        {{-- Keterangan --}}
        <div class="form-group">
            <label class="form-label" for="keterangan">Keterangan</label>
            <textarea id="keterangan"
                      name="keterangan"
                      class="form-control"
                      rows="3">{{ old('keterangan', $peminjaman->keterangan) }}</textarea>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            <a href="{{ route('peminjaman.index') }}" class="btn btn-neutral">Batal</a>
        </div>
    </form>
</div>

@endsection
