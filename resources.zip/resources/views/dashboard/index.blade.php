@extends('layouts.app')
@section('title', 'Dashboard')

@section('content')

<div class="page-header">
    <h1 class="page-title">Dashboard</h1>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon si-gold">&#9673;</div>
        <div>
            <div class="stat-number">{{ $totalPengguna }}</div>
            <div class="stat-label">Total Pengguna</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon si-blue">&#9672;</div>
        <div>
            <div class="stat-number">{{ $totalBarang }}</div>
            <div class="stat-label">Total Barang</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon si-green">&#8801;</div>
        <div>
            <div class="stat-number">{{ $totalPeminjaman }}</div>
            <div class="stat-label">Total Peminjaman</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon si-red">&#9719;</div>
        <div>
            <div class="stat-number">{{ $peminjamanAktif }}</div>
            <div class="stat-label">Sedang Dipinjam</div>
        </div>
    </div>
</div>

<div class="table-wrapper">
    <div class="table-toolbar">
        <span class="page-title" style="font-size:1rem;">Peminjaman Terbaru</span>
        <a href="{{ route('peminjaman.index') }}" class="btn btn-neutral">Lihat Semua</a>
    </div>
    <table>
        <thead>
            <tr>
                <th>Peminjam</th>
                <th>Barang</th>
                <th>Tanggal Pinjam</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            @forelse($peminjamanTerbaru as $item)
            <tr>
                <td>{{ $item->pengguna->nama_peminjam ?? '-' }}</td>
                <td>{{ $item->barang->nama_barang ?? '-' }}</td>
                <td>{{ \Carbon\Carbon::parse($item->tanggal_pinjam)->format('d M Y') }}</td>
                <td>
                    @php $st = $item->status instanceof \App\Enums\LoanStatus ? $item->status->value : $item->status; @endphp
                    @if($st === 'Dipinjam')
                        <span class="badge badge-warning">Dipinjam</span>
                    @elseif($st === 'Dikembalikan')
                        <span class="badge badge-success">Dikembalikan</span>
                    @else
                        <span class="badge badge-danger">Terlambat</span>
                    @endif
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="4">
                    <div class="empty-state">
                        <div class="empty-icon">&#8801;</div>
                        <p>Belum ada data peminjaman</p>
                    </div>
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>

@endsection
